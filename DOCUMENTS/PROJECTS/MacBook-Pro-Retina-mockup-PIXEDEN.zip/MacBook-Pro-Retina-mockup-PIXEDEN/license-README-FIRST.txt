---------------------------------------------
PIXEDEN // Resource license terms
---------------------------------------------
All our resources are royalty free for use in both personal and commercial projects.

You can modify any resources to your liking to fit into your project, we are however not legally liable for any misuse of our resources.

We do not ask for you to include any attribution or link back to Pixeden.com, we do however appreciate if you do credit our resources or/and help spread the word about us.

You cannot however redistribute, resell, lease, license, sub-license or offer our resources to any third party. This includes uploading our resources to another website, marketplace or media-sharing tool, and offering our resources as a separate attachment from any of your work. If you do plan to include one of our resource on an item or template that will be sold on a website or marketplace, we ask of you to contact us to determine the proper use of our resource before doing so. 
If you would like to share one of our resource you can do so making a link to the specific resource page on Pixeden.com

---------------------------------------------
Find more great resources @ Pixeden.com
Sincerely,
The Pixeden Team.
---------------------------------------------
http://www.pixeden.com
PS. Those terms might change as we update our license on our website, please be sure to check the latest license terms on our website to avoid any misuse of our resources.
Thank you. 